import express from 'express';
import helmet from 'helmet';
import compression from 'compression';
import cors from 'cors';
import rateLimit from 'express-rate-limit';

import healthRoutes from './routes/healthRoutes.js';
import newsRoutes from './routes/newsRoutes.js';
import metaRoutes from './routes/metaRoutes.js';
import mediaRoutes from './routes/mediaRoutes.js';
import hardwareRoutes from './routes/hardwareRoutes.js';
import { errorHandler, notFoundHandler } from './middleware/errorHandler.js';

const app = express();

app.disable('x-powered-by');
app.set('etag', 'strong');

if (String(process.env.TRUST_PROXY || '1') !== '0' && String(process.env.TRUST_PROXY || '').toLowerCase() !== 'false') {
  app.set('trust proxy', 1);
}

app.use(
  helmet({
    crossOriginEmbedderPolicy: false,
    contentSecurityPolicy: false,
    crossOriginResourcePolicy: false
  })
);

app.use(compression());
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true }));

if (String(process.env.ENABLE_CORS || 'true').toLowerCase() !== 'false') {
  app.use(
    cors({
      origin: true,
      credentials: false,
      methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
      allowedHeaders: ['Content-Type', 'Authorization', 'X-Refresh-Token'],
      maxAge: 86400
    })
  );

  app.options('*', cors());
}

app.use(
  rateLimit({
    windowMs: 60 * 1000,
    max: 120,
    standardHeaders: true,
    legacyHeaders: false
  })
);

app.get('/', (_req, res) => {
  res.json({
    ok: true,
    service: 'technetgame-backend',
    message: 'API online'
  });
});

app.get('/ping', (_req, res) => {
  res.send('pong');
});

app.use('/api', healthRoutes);
app.use('/api', metaRoutes);
app.use('/api', newsRoutes);
app.use('/api/media', mediaRoutes);
app.use('/api/hardware', hardwareRoutes);

app.use(notFoundHandler);
app.use(errorHandler);

export default app;
